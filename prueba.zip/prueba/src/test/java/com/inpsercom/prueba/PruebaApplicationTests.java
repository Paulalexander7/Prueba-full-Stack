package com.inpsercom.prueba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaApplicationTests {

	@Test
	void contextLoads() {
	}

}
